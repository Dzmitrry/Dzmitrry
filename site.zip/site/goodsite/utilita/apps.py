from django.apps import AppConfig


class UtilitaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'utilita'
