from django.http import HttpResponse,HttpResponseNotFound, Http404
from django.shortcuts import render,redirect, get_object_or_404

from .models import *

menu = ["О сайте", "Добавить статью", "Обратная связь", "Войти"]
cat = Category.objects.all()

def index(request):
    posts = Utilita.objects.all()
    return render(request, 'utilita/index.html', {'posts': posts,'menu': menu, 'title': 'Главная страница', 'cat': cat})
def about(request):
    return render(request, 'utilita/index.html', {'menu': menu, 'title': 'О сайте'})


def pageNotFound(request, exception):
    return HttpResponseNotFound('<h1> Страница неактивна </h1>')

def post(request, post_slug):
    post = get_object_or_404(Utilita, slug=post_slug)
    content = {'post': post,
               'menu': Category.onjects.all()
               }
    return render(request, 'utilita/post.html', content)