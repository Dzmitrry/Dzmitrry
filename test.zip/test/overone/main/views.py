from django.shortcuts import render

def index(request):
    return render(request, 'main/index.html')

def contact(request):
    if request.method == 'POST':
        form = Feedback(request.POST)
        if form.is_valid():
            subject = "Пробное сообщение"
            body = {
                'name': form.cleaned_data['first_name'],
                'email': form.cleaned_data['email_address'],
                'message': form.cleaned_data['message'],
            }
            message = "\n".join(body.values())


    form = Feedback()
    return render(request, "contact.html", {'form': form})
