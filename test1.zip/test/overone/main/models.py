from django.db import models

class Feedback(models.Model):
    name = models.CharField('Имя', max_length=20, help_text='Максимум 20 символов')
    email = models.EmailField('Почта')
    message = models.TextField('Сообщение ')
    def __str__(self):
        name = self.name
        email = self.email
        message = self.message
        return self.message


class Entry(models.Model):
    topic = models.ForeignKey('Topic', on_delete=models.CASCADE)
    text = models.TextField()
    date_added = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name_plural = 'entries'

    def __str__(self):
        if len(str(self.text)) > 50:
            return self.text[:50] + "..."
        return self.text
